var s;const a=((s=globalThis.__sveltekit_1t6gtht)==null?void 0:s.base)??"";var t;const e=((t=globalThis.__sveltekit_1t6gtht)==null?void 0:t.assets)??a;export{e as a,a as b};
