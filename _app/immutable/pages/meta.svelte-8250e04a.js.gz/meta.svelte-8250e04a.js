import{S as re,i as de,s as ue,e as o,t as n,k as y,c,a as r,h as s,d as i,m as k,b as h,g as he,J as e,n as V}from"../chunks/index-426c992b.js";const ve="Korolev",me="Plutoniumm",_e="SEDSCelestiaBPGC",be={current:6,previous:5,version:"3.3.2"},fe=1655500924757;var m={name:ve,author:me,owner:_e,build:be,time:fe};function pe(B){let l,t,_,S,D,b,W=m.name+"",I,N,f,X=m.author+"",O,F,p,Y=m.owner+"",H,G,v,M,Z=new Date(m.time).toLocaleString("en-GB",B[0])+"",P,R,T,$,E,ee=m.build.current+"",q,A,g,te=m.build.version+"",J,K,x,L,d,C,j,z;return{c(){l=o("main"),t=o("section"),_=o("h1"),S=n("Build Check"),D=y(),b=o("b"),I=n(W),N=n(" created by "),f=o("i"),O=n(X),F=n(` of
        `),p=o("i"),H=n(Y),G=n(`
        was last built
        `),v=o("code"),M=n(`\xA0
            `),P=n(Z),R=y(),T=o("br"),$=n(`
        this is build number `),E=o("code"),q=n(ee),A=n(` of version
        `),g=o("code"),J=n(te),K=y(),x=o("hr"),L=y(),d=o("section"),C=o("h1"),j=n("Functional Check"),z=n(`
        No External Functions!`),this.h()},l(w){l=c(w,"MAIN",{class:!0});var u=r(l);t=c(u,"SECTION",{id:!0,class:!0,bg:!0});var a=r(t);_=c(a,"H1",{});var ae=r(_);S=s(ae,"Build Check"),ae.forEach(i),D=k(a),b=c(a,"B",{});var ne=r(b);I=s(ne,W),ne.forEach(i),N=s(a," created by "),f=c(a,"I",{});var se=r(f);O=s(se,X),se.forEach(i),F=s(a,` of
        `),p=c(a,"I",{});var le=r(p);H=s(le,Y),le.forEach(i),G=s(a,`
        was last built
        `),v=c(a,"CODE",{});var Q=r(v);M=s(Q,`\xA0
            `),P=s(Q,Z),Q.forEach(i),R=k(a),T=c(a,"BR",{}),$=s(a,`
        this is build number `),E=c(a,"CODE",{});var oe=r(E);q=s(oe,ee),oe.forEach(i),A=s(a,` of version
        `),g=c(a,"CODE",{});var ce=r(g);J=s(ce,te),ce.forEach(i),a.forEach(i),K=k(u),x=c(u,"HR",{class:!0}),L=k(u),d=c(u,"SECTION",{class:!0,bg:!0});var U=r(d);C=c(U,"H1",{});var ie=r(C);j=s(ie,"Functional Check"),ie.forEach(i),z=s(U,`
        No External Functions!`),U.forEach(i),u.forEach(i),this.h()},h(){h(t,"id","BuildCheck"),h(t,"class","tx-c p-10 m-10 svelte-2vvcbp"),h(t,"bg","b5e-83c"),h(x,"class","w-50"),h(d,"class","tx-c p-10 m-10 svelte-2vvcbp"),h(d,"bg","e66-c26"),h(l,"class","tx-c w-100 svelte-2vvcbp")},m(w,u){he(w,l,u),e(l,t),e(t,_),e(_,S),e(t,D),e(t,b),e(b,I),e(t,N),e(t,f),e(f,O),e(t,F),e(t,p),e(p,H),e(t,G),e(t,v),e(v,M),e(v,P),e(t,R),e(t,T),e(t,$),e(t,E),e(E,q),e(t,A),e(t,g),e(g,J),e(l,K),e(l,x),e(l,L),e(l,d),e(d,C),e(C,j),e(d,z)},p:V,i:V,o:V,d(w){w&&i(l)}}}function Ee(B){return[{weekday:"short",year:"numeric",hour:"2-digit",minute:"2-digit",hour12:!1,month:"short",day:"numeric"}]}class Ce extends re{constructor(l){super(),de(this,l,Ee,pe,ue,{})}}export{Ce as default};
