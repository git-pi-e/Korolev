import{a as t}from"../chunks/entry.6LNEOwME.js";export{t as start};
