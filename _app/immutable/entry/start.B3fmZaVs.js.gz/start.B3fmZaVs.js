import{a as t}from"../chunks/entry.BUG1zAiE.js";export{t as start};
