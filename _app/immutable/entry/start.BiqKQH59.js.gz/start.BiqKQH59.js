import{a as t}from"../chunks/entry.BTS44CYE.js";export{t as start};
