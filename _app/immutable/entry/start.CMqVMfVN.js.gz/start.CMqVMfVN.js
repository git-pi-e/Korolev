import{a as t}from"../chunks/entry.D-n-2smP.js";export{t as start};
