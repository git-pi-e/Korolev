import{a as t}from"../chunks/entry.Vq7zJTGO.js";export{t as start};
