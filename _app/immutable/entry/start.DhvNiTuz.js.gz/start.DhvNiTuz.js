import{a as t}from"../chunks/entry.CGFHsmPF.js";export{t as start};
